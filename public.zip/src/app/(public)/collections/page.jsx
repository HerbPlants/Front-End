import React from 'react'

const CollectionsPage = () => {
  return (
    <div>CollectionsPage</div>
  )
}

export default CollectionsPage