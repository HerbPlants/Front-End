import React from 'react'

const ChallagePage = () => {
  return (
    <div>ChallagePage</div>
  )
}

export default ChallagePage